// Advanced Al-Khidmat Hospital Ward Management System JavaScript

class AlKhidmatHospitalApp {
    constructor() {
        this.currentPage = 'dashboard';
        this.data = {
            patients: [],
            doctors: [],
            beds: this.generateBeds(20),
            settings: {
                theme: 'light',
                notifications: true,
                autoSave: true
            }
        };
        
        this.charts = {};
        this.recognition = null;
        this.currentPatient = null;
        this.currentDoctor = null;
        
        this.init();
    }

    // Initialize the application
    init() {
        this.initializeData();
        this.initializeSpeechRecognition();
        this.bindEvents();
        this.startClock();
        this.loadDashboard();
    }

    // Data Management
    initializeData() {
        const savedData = localStorage.getItem('alkhidmatHospitalData');
        if (savedData) {
            this.data = { ...this.data, ...JSON.parse(savedData) };
        } else {
            this.generateSampleData();
            this.saveData();
        }
    }

    generateSampleData() {
        // Generate sample patients
        const samplePatients = [
            {
                id: 1,
                name: 'Fatima Khan',
                patientId: 'P001',
                cnic: '42101-1234567-8',
                age: 28,
                phone: '+92-300-1234567',
                bedNumber: 1,
                condition: 'Normal',
                shift: 'Morning',
                address: 'Block A, Gulshan-e-Iqbal, Karachi',
                description: 'Regular checkup and monitoring for prenatal care',
                status: 'Admitted',
                admissionDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
            },
            {
                id: 2,
                name: 'Aisha Ahmed',
                patientId: 'P002',
                cnic: '42201-2345678-9',
                age: 32,
                phone: '+92-301-2345678',
                bedNumber: 3,
                condition: 'Critical',
                shift: 'Evening',
                address: 'Defence Phase 2, Karachi',
                description: 'Post-operative care required after cesarean section',
                status: 'Under Treatment',
                admissionDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
            },
            {
                id: 3,
                name: 'Zainab Ali',
                patientId: 'P003',
                cnic: '42301-3456789-0',
                age: 25,
                phone: '+92-302-3456789',
                bedNumber: 5,
                condition: 'Other',
                shift: 'Night',
                address: 'Nazimabad Block 3, Karachi',
                description: 'Routine prenatal care and monitoring',
                status: 'Admitted',
                admissionDate: new Date().toISOString()
            },
            {
                id: 4,
                name: 'Mariam Sheikh',
                patientId: 'P004',
                cnic: '42401-4567890-1',
                age: 30,
                phone: '+92-303-4567890',
                bedNumber: 7,
                condition: 'Normal',
                shift: 'Morning',
                address: 'Clifton Block 5, Karachi',
                description: 'Regular gynecological examination',
                status: 'Admitted',
                admissionDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
            }
        ];

        // Generate sample doctors
        const sampleDoctors = [
            {
                id: 1,
                name: 'Dr. Sadia Malik',
                specialization: 'Gynecologist',
                contact: '+92-321-1001001',
                email: 's.malik@alkhidmat.org',
                experience: 15,
                shift: 'Morning',
                patients: [1, 4],
                cases: 150
            },
            {
                id: 2,
                name: 'Dr. Ahmed Hassan',
                specialization: 'Obstetrician',
                contact: '+92-321-1002002',
                email: 'a.hassan@alkhidmat.org',
                experience: 12,
                shift: 'Evening',
                patients: [2],
                cases: 120
            },
            {
                id: 3,
                name: 'Dr. Farah Noor',
                specialization: 'Reproductive Endocrinologist',
                contact: '+92-321-1003003',
                email: 'f.noor@alkhidmat.org',
                experience: 8,
                shift: 'Night',
                patients: [3],
                cases: 85
            },
            {
                id: 4,
                name: 'Dr. Khadija Iqbal',
                specialization: 'Maternal-Fetal Medicine',
                contact: '+92-321-1004004',
                email: 'k.iqbal@alkhidmat.org',
                experience: 10,
                shift: 'Morning',
                patients: [],
                cases: 95
            }
        ];

        this.data.patients = samplePatients;
        this.data.doctors = sampleDoctors;

        // Update bed assignments
        samplePatients.forEach(patient => {
            const bed = this.data.beds.find(b => b.number === patient.bedNumber);
            if (bed) {
                bed.occupied = true;
                bed.patient = patient;
            }
        });
    }

    generateBeds(count) {
        const beds = [];
        for (let i = 1; i <= count; i++) {
            beds.push({
                number: i,
                occupied: false,
                patient: null,
                type: 'Standard',
                floor: Math.ceil(i / 10)
            });
        }
        return beds;
    }

    saveData() {
        if (this.data.settings.autoSave) {
            localStorage.setItem('alkhidmatHospitalData', JSON.stringify(this.data));
        }
    }

    // Event Binding
    bindEvents() {
        this.bindNavigationEvents();
        this.bindModalEvents();
        this.bindFormEvents();
        this.bindTableEvents();
        this.bindSearchEvents();
        this.bindThemeEvents();
    }

    bindNavigationEvents() {
        // Sidebar navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.navigateToPage(page);
            });
        });

        // Mobile sidebar toggle
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                document.querySelector('.sidebar').classList.toggle('open');
            });
        }
    }

    bindModalEvents() {
        // Modal close events
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                this.closeModal(modal.id);
            });
        });

        // Click outside to close modal
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    bindFormEvents() {
        // Voice recording events
        const voiceRecordBtn = document.getElementById('voiceRecordBtn');
        const voicePlayBtn = document.getElementById('voicePlayBtn');

        if (voiceRecordBtn) {
            voiceRecordBtn.addEventListener('click', () => this.startVoiceRecording());
        }

        if (voicePlayBtn) {
            voicePlayBtn.addEventListener('click', () => this.playDescription());
        }

        // Auto-populate bed options
        this.populateBedOptions();
    }

    bindTableEvents() {
        // Select all checkbox
        const selectAllCheckbox = document.getElementById('selectAllPatients');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                const checkboxes = document.querySelectorAll('#patientsTableBody input[type="checkbox"]');
                checkboxes.forEach(cb => cb.checked = e.target.checked);
            });
        }
    }

    bindSearchEvents() {
        // Global search
        const globalSearch = document.querySelector('.global-search');
        if (globalSearch) {
            globalSearch.addEventListener('input', (e) => {
                this.performGlobalSearch(e.target.value);
            });
        }

        // Patient search and filters
        const patientSearch = document.getElementById('patientSearch');
        const conditionFilter = document.getElementById('conditionFilter');
        const shiftFilter = document.getElementById('shiftFilter');
        const statusFilter = document.getElementById('statusFilter');

        if (patientSearch) {
            patientSearch.addEventListener('input', () => this.filterPatients());
        }

        [conditionFilter, shiftFilter, statusFilter].forEach(filter => {
            if (filter) {
                filter.addEventListener('change', () => this.filterPatients());
            }
        });
    }

    bindThemeEvents() {
        const themeToggle = document.querySelector('.theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
    }

    // Navigation Management
    navigateToPage(pageName) {
        // Update active navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-page="${pageName}"]`).classList.add('active');

        // Show/hide pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        document.getElementById(`${pageName}-page`).classList.add('active');

        this.currentPage = pageName;

        // Load page-specific content
        switch (pageName) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'patients':
                this.loadPatients();
                break;
            case 'doctors':
                this.loadDoctors();
                break;
            case 'beds':
                this.loadBeds();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
            case 'reports':
                this.loadReports();
                break;
        }
    }

    // Clock Management
    startClock() {
        this.updateClock();
        setInterval(() => this.updateClock(), 1000);
    }

    updateClock() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const dateString = now.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });

        const timeElement = document.getElementById('liveTime');
        const dateElement = document.getElementById('liveDate');
        
        if (timeElement) timeElement.textContent = timeString;
        if (dateElement) dateElement.textContent = dateString;
    }

    // Speech Recognition
    initializeSpeechRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onresult = (event) => {
                const result = event.results[0][0].transcript;
                const descriptionField = document.getElementById('patientDescription');
                if (descriptionField) {
                    descriptionField.value = result;
                }
            };

            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.showToast('Error', 'Speech recognition failed', 'error');
            };
        }
    }

    startVoiceRecording() {
    if (!this.recognition) {
        this.showToast('Error', 'Speech recognition not supported', 'error');
        return;
    }

    const btn = document.getElementById('voiceRecordBtn');
    const descriptionField = document.getElementById('patientDescription');

    btn.innerHTML = '<i class="fas fa-stop"></i>';
    btn.style.background = 'var(--danger-dark)';

    this.recognition.onresult = (event) => {
        const result = event.results[0][0].transcript;
        if (descriptionField) {
            descriptionField.value += (descriptionField.value ? ' ' : '') + result;
        }
    };

    this.recognition.onend = () => {
        btn.innerHTML = '<i class="fas fa-microphone"></i>';
        btn.style.background = 'var(--danger-color)';
    };

    this.recognition.onerror = (event) => {
        this.showToast('Error', `Mic error: ${event.error}`, 'error');
        btn.innerHTML = '<i class="fas fa-microphone"></i>';
        btn.style.background = 'var(--danger-color)';
    };

    try {
        this.recognition.start();
    } catch (e) {
        this.showToast('Error', 'Could not start mic. Check permissions.', 'error');
    }
}


    playDescription() {
        const description = document.getElementById('patientDescription').value;
        if (description && 'speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(description);
            utterance.rate = 0.8;
            utterance.pitch = 1;
            speechSynthesis.speak(utterance);
        } else {
            this.showToast('Error', 'Text-to-speech not available', 'error');
        }
    }

    // Dashboard Management
    loadDashboard() {
        this.updateStatistics();
        this.loadRecentPatients();
        this.loadCriticalAlerts();
        this.loadDoctorSchedule();
        this.initializeDashboardCharts();
    }

    updateStatistics() {
        const totalPatients = this.data.patients.length;
        const criticalPatients = this.data.patients.filter(p => p.condition === 'Critical').length;
        const availableBeds = this.data.beds.filter(b => !b.occupied).length;
        const activeDoctors = this.data.doctors.length;

        const totalPatientsEl = document.getElementById('totalPatients');
        const criticalPatientsEl = document.getElementById('criticalPatients');
        const availableBedsEl = document.getElementById('availableBeds');
        const activeDoctorsEl = document.getElementById('activeDoctors');

        if (totalPatientsEl) totalPatientsEl.textContent = totalPatients;
        if (criticalPatientsEl) criticalPatientsEl.textContent = criticalPatients;
        if (availableBedsEl) availableBedsEl.textContent = availableBeds;
        if (activeDoctorsEl) activeDoctorsEl.textContent = activeDoctors;
    }

    loadRecentPatients() {
        const recentPatients = this.data.patients
            .sort((a, b) => new Date(b.admissionDate) - new Date(a.admissionDate))
            .slice(0, 5);

        const container = document.getElementById('recentPatientsList');
        if (!container) return;
        
        container.innerHTML = '';

        recentPatients.forEach(patient => {
            const patientElement = document.createElement('div');
            patientElement.className = 'patient-item';
            patientElement.innerHTML = `
                <div class="patient-avatar">
                    ${patient.name.charAt(0)}
                </div>
                <div class="patient-info">
                    <div class="patient-name">${patient.name}</div>
                    <div class="patient-details">ID: ${patient.patientId} • Bed ${patient.bedNumber}</div>
                </div>
                <div class="patient-status status-${patient.condition.toLowerCase()}">
                    ${patient.condition}
                </div>
            `;
            patientElement.addEventListener('click', () => this.showPatientDetails(patient));
            container.appendChild(patientElement);
        });
    }

    loadCriticalAlerts() {
        const criticalPatients = this.data.patients.filter(p => p.condition === 'Critical');
        const container = document.getElementById('criticalAlertsList');
        if (!container) return;
        
        container.innerHTML = '';

        criticalPatients.forEach(patient => {
            const alertElement = document.createElement('div');
            alertElement.className = 'alert-item';
            alertElement.innerHTML = `
                <div class="alert-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="alert-content">
                    <div class="alert-title">Critical Patient Alert</div>
                    <div class="alert-message">${patient.name} in Bed ${patient.bedNumber} requires immediate attention</div>
                    <div class="alert-time">${this.getTimeAgo(patient.admissionDate)}</div>
                </div>
            `;
            container.appendChild(alertElement);
        });

        if (criticalPatients.length === 0) {
            container.innerHTML = '<div class="alert-item"><div class="alert-content"><div class="alert-message">No critical alerts at this time</div></div></div>';
        }
    }

    loadDoctorSchedule() {
        const container = document.getElementById('doctorScheduleList');
        if (!container) return;
        
        container.innerHTML = '';

        // Generate sample schedule
        const scheduleItems = [
            { time: '09:00', doctor: 'Dr. Sadia Malik', task: 'Ward Rounds' },
            { time: '11:30', doctor: 'Dr. Ahmed Hassan', task: 'Surgery - Room 3' },
            { time: '14:00', doctor: 'Dr. Farah Noor', task: 'Patient Consultation' },
            { time: '16:30', doctor: 'Dr. Khadija Iqbal', task: 'Emergency Response' }
        ];

        scheduleItems.forEach(item => {
            const scheduleElement = document.createElement('div');
            scheduleElement.className = 'schedule-item';
            scheduleElement.innerHTML = `
                <div class="schedule-time">${item.time}</div>
                <div class="schedule-info">
                    <div class="schedule-doctor">${item.doctor}</div>
                    <div class="schedule-task">${item.task}</div>
                </div>
            `;
            container.appendChild(scheduleElement);
        });
    }

    initializeDashboardCharts() {
        // Initialize small charts in stat cards
        this.initializeStatCharts();
        
        // Initialize main occupancy chart
        this.initializeOccupancyChart();
    }

    initializeStatCharts() {
        // Small trend charts for statistics cards
        const chartConfigs = [
            { id: 'patientsChart', data: [12, 15, 13, 17, 14, 16, 18] },
            { id: 'criticalChart', data: [5, 3, 4, 2, 3, 1, 2] },
            { id: 'bedsChart', data: [8, 6, 7, 5, 6, 8, 7] },
            { id: 'doctorsChart', data: [3, 3, 4, 4, 4, 5, 5] }
        ];

        chartConfigs.forEach(config => {
            const canvas = document.getElementById(config.id);
            if (canvas) {
                new Chart(canvas, {
                    type: 'line',
                    data: {
                        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                        datasets: [{
                            data: config.data,
                            borderColor: '#3b82f6',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { display: false },
                            y: { display: false }
                        },
                        elements: { point: { radius: 0 } }
                    }
                });
            }
        });
    }

    initializeOccupancyChart() {
        const canvas = document.getElementById('occupancyChart');
        if (canvas) {
            // Generate sample data for the last 7 days
            const labels = [];
            const occupancyData = [];
            
            for (let i = 6; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
                occupancyData.push(Math.floor(Math.random() * 20) + 60); // 60-80% occupancy
            }

            new Chart(canvas, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Occupancy Rate (%)',
                        data: occupancyData,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#3b82f6',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    // Patient Management
    loadPatients() {
        this.displayPatients(this.data.patients);
    }

    displayPatients(patients) {
        const tbody = document.getElementById('patientsTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        patients.forEach(patient => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>
                    <input type="checkbox" value="${patient.id}">
                </td>
                <td>
                    <div class="patient-info-cell">
                        <div class="patient-avatar-small">
                            ${patient.name.charAt(0)}
                        </div>
                        <div class="patient-info-text">
                            <div class="patient-name-cell">${patient.name}</div>
                            <div class="patient-id-cell">ID: ${patient.patientId}</div>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="condition-badge condition-${patient.condition.toLowerCase()}">
                        ${patient.condition}
                    </span>
                </td>
                <td>
                    <span class="bed-badge">${patient.bedNumber}</span>
                </td>
                <td>${patient.shift}</td>
                <td>${new Date(patient.admissionDate).toLocaleDateString()}</td>
                <td>
                    <span class="status-badge status-${patient.status.toLowerCase().replace(' ', '-')}">
                        ${patient.status}
                    </span>
                </td>
                <td>
                    <div class="table-actions">
                        <button class="table-action-btn action-view" onclick="alkhidmatApp.showPatientDetails(${patient.id})" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="table-action-btn action-edit" onclick="alkhidmatApp.editPatient(${patient.id})" title="Edit Patient">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="table-action-btn action-delete" onclick="alkhidmatApp.deletePatient(${patient.id})" title="Delete Patient">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    // Doctor Management
    loadDoctors() {
        this.displayDoctors(this.data.doctors);
    }

    displayDoctors(doctors) {
        const container = document.getElementById('doctorsGrid');
        if (!container) return;
        
        container.innerHTML = '';

        doctors.forEach(doctor => {
            const doctorCard = document.createElement('div');
            doctorCard.className = 'doctor-card';
            doctorCard.innerHTML = `
                <div class="doctor-header">
                    <div class="doctor-avatar">
                        ${doctor.name.split(' ').map(n => n.charAt(0)).join('')}
                    </div>
                    <div class="doctor-info">
                        <div class="doctor-name">${doctor.name}</div>
                        <div class="doctor-specialization">${doctor.specialization}</div>
                    </div>
                </div>
                <div class="doctor-details">
                    <div class="doctor-detail-item">
                        <i class="fas fa-phone"></i>
                        <span>${doctor.contact}</span>
                    </div>
                    <div class="doctor-detail-item">
                        <i class="fas fa-envelope"></i>
                        <span>${doctor.email}</span>
                    </div>
                    <div class="doctor-detail-item">
                        <i class="fas fa-clock"></i>
                        <span>${doctor.shift} Shift</span>
                    </div>
                    <div class="doctor-detail-item">
                        <i class="fas fa-calendar"></i>
                        <span>${doctor.experience} Years Experience</span>
                    </div>
                </div>
                <div class="doctor-stats">
                    <div class="doctor-stat">
                        <div class="doctor-stat-value">${doctor.patients.length}</div>
                        <div class="doctor-stat-label">Patients</div>
                    </div>
                    <div class="doctor-stat">
                        <div class="doctor-stat-value">${doctor.cases}</div>
                        <div class="doctor-stat-label">Cases</div>
                    </div>
                    <div class="doctor-stat">
                        <div class="doctor-stat-value">${doctor.experience}</div>
                        <div class="doctor-stat-label">Years</div>
                    </div>
                </div>
                <div class="doctor-actions">
                    <button class="doctor-action-btn doctor-primary" onclick="alkhidmatApp.viewDoctorDetails(${doctor.id})">
                        View Details
                    </button>
                    <button class="doctor-action-btn doctor-secondary" onclick="alkhidmatApp.editDoctor(${doctor.id})">
                        Edit
                    </button>
                </div>
            `;
            container.appendChild(doctorCard);
        });
    }

    // Bed Management
    loadBeds() {
        this.displayBeds(this.data.beds);
        this.updateBedSummary();
    }

    displayBeds(beds) {
        const container = document.getElementById('bedsGrid');
        if (!container) return;
        
        container.innerHTML = '';

        beds.forEach(bed => {
            const bedCard = document.createElement('div');
            let cardClass = 'bed-card ';
            
            if (bed.occupied && bed.patient) {
                switch (bed.patient.condition) {
                    case 'Critical':
                        cardClass += 'occupied-critical';
                        break;
                    case 'Normal':
                        cardClass += 'occupied-normal';
                        break;
                    case 'Other':
                        cardClass += 'occupied-other';
                        break;
                    default:
                        cardClass += 'available';
                }
            } else {
                cardClass += 'available';
            }
            
            bedCard.className = cardClass;
            
            if (bed.occupied && bed.patient) {
                bedCard.innerHTML = `
                    <div class="bed-header">
                        <div class="bed-number">
                            <i class="fas fa-bed"></i>
                            Bed ${bed.number}
                        </div>
                        <div class="bed-status ${bed.patient.condition.toLowerCase()}">
                            <i class="fas fa-circle"></i>
                            ${bed.patient.condition}
                        </div>
                    </div>
                    <div class="bed-content">
                        <div class="bed-patient-name">${bed.patient.name}</div>
                        <div class="bed-patient-id">ID: ${bed.patient.patientId}</div>
                        <div class="bed-patient-details">Shift: ${bed.patient.shift}</div>
                    </div>
                    <div class="bed-actions">
                        <button class="bed-action-btn bed-view" onclick="alkhidmatApp.showPatientDetails(${bed.patient.id})">
                            View Patient
                        </button>
                    </div>
                `;
            } else {
                bedCard.innerHTML = `
                    <div class="bed-header">
                        <div class="bed-number">
                            <i class="fas fa-bed"></i>
                            Bed ${bed.number}
                        </div>
                        <div class="bed-status available">
                            <i class="fas fa-check-circle"></i>
                            Available
                        </div>
                    </div>
                    <div class="bed-content">
                        <div class="bed-patient-name">Unoccupied</div>
                        <div class="bed-patient-details">Ready for patient assignment</div>
                    </div>
                    <div class="bed-actions">
                        <button class="bed-action-btn bed-assign" onclick="alkhidmatApp.assignBed(${bed.number})">
                            Assign Patient
                        </button>
                    </div>
                `;
            }
            
            container.appendChild(bedCard);
        });
    }

    updateBedSummary() {
        const totalBeds = this.data.beds.length;
        const occupiedBeds = this.data.beds.filter(b => b.occupied).length;
        const availableBeds = totalBeds - occupiedBeds;
        const criticalBeds = this.data.beds.filter(b => b.occupied && b.patient && b.patient.condition === 'Critical').length;

        const totalBedsEl = document.getElementById('totalBedsCount');
        const occupiedBedsEl = document.getElementById('occupiedBedsCount');
        const availableBedsEl = document.getElementById('availableBedsCount');
        const criticalBedsEl = document.getElementById('criticalBedsCount');

        if (totalBedsEl) totalBedsEl.textContent = totalBeds;
        if (occupiedBedsEl) occupiedBedsEl.textContent = occupiedBeds;
        if (availableBedsEl) availableBedsEl.textContent = availableBeds;
        if (criticalBedsEl) criticalBedsEl.textContent = criticalBeds;
    }

    // Analytics Management
    loadAnalytics() {
        this.initializeAnalyticsCharts();
    }

    initializeAnalyticsCharts() {
        this.initializeConditionPieChart();
        this.initializeAdmissionsTrendChart();
        this.initializeBedOccupancyChart();
        this.initializeDoctorWorkloadChart();
    }

    initializeConditionPieChart() {
        const canvas = document.getElementById('conditionPieChart');
        if (canvas) {
            const conditions = this.data.patients.reduce((acc, patient) => {
                acc[patient.condition] = (acc[patient.condition] || 0) + 1;
                return acc;
            }, {});

            new Chart(canvas, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(conditions),
                    datasets: [{
                        data: Object.values(conditions),
                        backgroundColor: ['#10b981', '#ef4444', '#f59e0b'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }

    initializeAdmissionsTrendChart() {
        const canvas = document.getElementById('admissionsTrendChart');
        if (canvas) {
            const labels = [];
            const admissionsData = [];
            
            for (let i = 6; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                admissionsData.push(Math.floor(Math.random() * 5) + 1);
            }

            new Chart(canvas, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Daily Admissions',
                        data: admissionsData,
                        backgroundColor: '#3b82f6',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }
    }

    initializeBedOccupancyChart() {
        const canvas = document.getElementById('bedOccupancyChart');
        if (canvas) {
            const labels = [];
            const occupancyData = [];
            
            for (let i = 29; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                occupancyData.push(Math.floor(Math.random() * 30) + 50);
            }

            new Chart(canvas, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Bed Occupancy (%)',
                        data: occupancyData,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    initializeDoctorWorkloadChart() {
        const canvas = document.getElementById('doctorWorkloadChart');
        if (canvas) {
            const doctorNames = this.data.doctors.map(d => d.name.split(' ')[1]);
            const workloadData = this.data.doctors.map(d => d.patients.length);

            new Chart(canvas, {
                type: 'horizontalBar',
                data: {
                    labels: doctorNames,
                    datasets: [{
                        label: 'Current Patients',
                        data: workloadData,
                        backgroundColor: '#f59e0b',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }
    }

    // Reports Management
    loadReports() {
        // Placeholder for reports loading
        console.log('Reports page loaded');
    }

    // Modal Management
    showPatientDetails(patientId) {
        const patient = this.data.patients.find(p => p.id === patientId);
        if (!patient) return;

        const modal = document.getElementById('patientDetailsModal');
        const title = document.getElementById('patientDetailsTitle');
        const content = document.getElementById('patientDetailsContent');

        title.textContent = `Patient Details - ${patient.name}`;
        content.innerHTML = `
            <div class="patient-details-grid">
                <div class="detail-section">
                    <h4>Personal Information</h4>
                    <div class="detail-item">
                        <label>Full Name:</label>
                        <span>${patient.name}</span>
                    </div>
                    <div class="detail-item">
                        <label>Patient ID:</label>
                        <span>${patient.patientId}</span>
                    </div>
                    <div class="detail-item">
                        <label>CNIC:</label>
                        <span>${patient.cnic}</span>
                    </div>
                    <div class="detail-item">
                        <label>Age:</label>
                        <span>${patient.age} years</span>
                    </div>
                    <div class="detail-item">
                        <label>Phone:</label>
                        <span>${patient.phone}</span>
                    </div>
                    <div class="detail-item">
                        <label>Address:</label>
                        <span>${patient.address}</span>
                    </div>
                </div>
                <div class="detail-section">
                    <h4>Medical Information</h4>
                    <div class="detail-item">
                        <label>Condition:</label>
                        <span class="condition-badge condition-${patient.condition.toLowerCase()}">${patient.condition}</span>
                    </div>
                    <div class="detail-item">
                        <label>Status:</label>
                        <span class="status-badge status-${patient.status.toLowerCase().replace(' ', '-')}">${patient.status}</span>
                    </div>
                    <div class="detail-item">
                        <label>Bed Number:</label>
                        <span class="bed-badge">${patient.bedNumber}</span>
                    </div>
                    <div class="detail-item">
                        <label>Shift:</label>
                        <span>${patient.shift}</span>
                    </div>
                    <div class="detail-item">
                        <label>Admission Date:</label>
                        <span>${new Date(patient.admissionDate).toLocaleDateString()}</span>
                    </div>
                    <div class="detail-item full-width">
                        <label>Medical Description:</label>
                        <p>${patient.description}</p>
                        <button class="btn btn-secondary" onclick="alkhidmatApp.playDescription('${patient.description}')">
                            <i class="fas fa-volume-up"></i> Play Description
                        </button>
                    </div>
                </div>
            </div>
        `;

        modal.classList.add('active');
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    // Utility Functions
    getTimeAgo(date) {
        const now = new Date();
        const timeDifference = now - new Date(date);
        const secondsDifference = Math.floor(timeDifference / 1000);

        if (secondsDifference < 60) {
            return `${secondsDifference} seconds ago`;
        } else if (secondsDifference < 3600) {
            const minutesDifference = Math.floor(secondsDifference / 60);
            return `${minutesDifference} minutes ago`;
        } else if (secondsDifference < 86400) {
            const hoursDifference = Math.floor(secondsDifference / 3600);
            return `${hoursDifference} hours ago`;
        } else {
            const daysDifference = Math.floor(secondsDifference / 86400);
            return `${daysDifference} days ago`;
        }
    }

    showToast(title, message, type = 'success') {
        const toast = document.getElementById('notificationToast');
        const toastTitle = toast.querySelector('.toast-title');
        const toastText = toast.querySelector('.toast-text');
        const toastIcon = toast.querySelector('.toast-icon i');

        toastTitle.textContent = title;
        toastText.textContent = message;

        // Update icon based on type
        switch (type) {
            case 'success':
                toastIcon.className = 'fas fa-check-circle';
                break;
            case 'error':
                toastIcon.className = 'fas fa-exclamation-circle';
                break;
            case 'warning':
                toastIcon.className = 'fas fa-exclamation-triangle';
                break;
            default:
                toastIcon.className = 'fas fa-info-circle';
        }

        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    populateBedOptions() {
        const bedSelect = document.getElementById('patientBed');
        if (bedSelect) {
            bedSelect.innerHTML = '<option value="">Select Bed</option>';
            this.data.beds.filter(bed => !bed.occupied).forEach(bed => {
                const option = document.createElement('option');
                option.value = bed.number;
                option.textContent = `Bed ${bed.number} (Floor ${bed.floor})`;
                bedSelect.appendChild(option);
            });
        }
    }

    performGlobalSearch(query) {
        if (!query.trim()) return;

        const results = [];
        
        // Search patients
        this.data.patients.forEach(patient => {
            if (patient.name.toLowerCase().includes(query.toLowerCase()) ||
                patient.patientId.toLowerCase().includes(query.toLowerCase()) ||
                patient.cnic.includes(query)) {
                results.push({ type: 'patient', data: patient });
            }
        });

        // Search doctors
        this.data.doctors.forEach(doctor => {
            if (doctor.name.toLowerCase().includes(query.toLowerCase()) ||
                doctor.specialization.toLowerCase().includes(query.toLowerCase())) {
                results.push({ type: 'doctor', data: doctor });
            }
        });

        console.log('Search results:', results);
        // Implement search results display
    }

    filterPatients() {
        const searchTerm = document.getElementById('patientSearch')?.value.toLowerCase() || '';
        const conditionFilter = document.getElementById('conditionFilter')?.value || '';
        const shiftFilter = document.getElementById('shiftFilter')?.value || '';
        const statusFilter = document.getElementById('statusFilter')?.value || '';

        let filteredPatients = this.data.patients.filter(patient => {
            const matchesSearch = patient.name.toLowerCase().includes(searchTerm) ||
                                patient.patientId.toLowerCase().includes(searchTerm) ||
                                patient.cnic.includes(searchTerm);
            const matchesCondition = !conditionFilter || patient.condition === conditionFilter;
            const matchesShift = !shiftFilter || patient.shift === shiftFilter;
            const matchesStatus = !statusFilter || patient.status === statusFilter;

            return matchesSearch && matchesCondition && matchesShift && matchesStatus;
        });

        this.displayPatients(filteredPatients);
    }

    toggleTheme() {
        const currentTheme = this.data.settings.theme;
        this.data.settings.theme = currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', this.data.settings.theme);
        
        const themeIcon = document.querySelector('.theme-toggle i');
        if (themeIcon) {
            themeIcon.className = this.data.settings.theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
        
        this.saveData();
    }

    // Placeholder functions for modal actions
    editPatient(patientId) {
        console.log('Edit patient:', patientId);
        this.showToast('Info', 'Edit patient functionality coming soon', 'info');
    }

    deletePatient(patientId) {
        if (confirm('Are you sure you want to delete this patient?')) {
            this.data.patients = this.data.patients.filter(p => p.id !== patientId);
            this.saveData();
            this.loadPatients();
            this.showToast('Success', 'Patient deleted successfully');
        }
    }

    viewDoctorDetails(doctorId) {
        console.log('View doctor details:', doctorId);
        this.showToast('Info', 'Doctor details functionality coming soon', 'info');
    }

    editDoctor(doctorId) {
        console.log('Edit doctor:', doctorId);
        this.showToast('Info', 'Edit doctor functionality coming soon', 'info');
    }

    assignBed(bedNumber) {
        console.log('Assign bed:', bedNumber);
        this.showToast('Info', 'Bed assignment functionality coming soon', 'info');
    }
}

// Global functions for onclick handlers
function showAddPatientModal() {
    document.getElementById('addPatientModal').classList.add('active');
}

function showAddDoctorModal() {
    document.getElementById('addDoctorModal').classList.add('active');
}

function closeModal(modalId) {
    alkhidmatApp.closeModal(modalId);
}

function savePatient() {
    const name = document.getElementById('patientName').value.trim();
    const patientId = document.getElementById('patientId').value.trim();
    const cnic = document.getElementById('patientCnic').value.trim();
    const age = parseInt(document.getElementById('patientAge').value.trim());
    const phone = document.getElementById('patientPhone').value.trim();
    const shift = document.getElementById('patientShift').value;
    const address = document.getElementById('patientAddress').value.trim();
    const description = document.getElementById('patientDescription').value.trim();
    const condition = document.getElementById('patientCondition')?.value || 'Normal';
    const bedNumber = parseInt(document.getElementById('patientBed').value);

    if (!name || !patientId || !cnic || !bedNumber) {
        alkhidmatApp.showToast('Error', 'Please fill in all required fields', 'error');
        return;
    }

    const duplicate = alkhidmatApp.data.patients.find(p => p.patientId === patientId);
    if (duplicate) {
        alkhidmatApp.showToast('Error', 'Patient ID already exists', 'error');
        return;
    }

    const newPatient = {
        id: Date.now(),
        name,
        patientId,
        cnic,
        age: isNaN(age) ? null : age,
        phone,
        bedNumber,
        condition,
        shift,
        address,
        description,
        status: 'Admitted',
        admissionDate: new Date().toISOString()
    };

    // Save to system
    alkhidmatApp.data.patients.push(newPatient);

    // Mark bed as occupied
    const bed = alkhidmatApp.data.beds.find(b => b.number === bedNumber);
    if (bed) {
        bed.occupied = true;
        bed.patient = newPatient;
    }

    // Save and update UI
    alkhidmatApp.saveData();
    alkhidmatApp.loadPatients();
    alkhidmatApp.loadDashboard();
    alkhidmatApp.showToast('Success', 'Patient added successfully');

    closeModal('addPatientModal');
}

function saveDoctor() {
    // Implement save doctor functionality
    alkhidmatApp.showToast('Success', 'Doctor saved successfully');
    closeModal('addDoctorModal');
}

function exportPatients() {
    alkhidmatApp.showToast('Info', 'Export functionality coming soon', 'info');
}

function showBedAssignment() {
    alkhidmatApp.showToast('Info', 'Bed assignment functionality coming soon', 'info');
}

function generateReport() {
    alkhidmatApp.showToast('Info', 'Report generation functionality coming soon', 'info');
}

// Initialize the application
let alkhidmatApp;
document.addEventListener('DOMContentLoaded', () => {
    alkhidmatApp = new AlKhidmatHospitalApp();
});